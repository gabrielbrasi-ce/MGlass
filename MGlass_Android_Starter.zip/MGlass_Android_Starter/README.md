# MGlass — base inicial Android + servidor

Esta é uma base de desenvolvimento executável, não uma versão de produção completa.

## O que já está preparado
- Aplicativo Flutter para Android com tela de entrar/criar conta e tela inicial.
- API Node.js/Express com cadastro, login e consulta do perfil.
- PostgreSQL via Docker Compose.
- Senhas armazenadas com bcrypt e sessões via JWT.
- SQL do schema complementar MGlass incluído em `server/db/schema.sql`.

## Ainda não implementado
Mensagens em tempo real, Matrix/Olm/Megolm E2EE, sincronização de dispositivos, upload criptografado S3, status 24h, chamadas LiveKit/WebRTC, push notifications, moderação e recuperação segura de conta. Não use esta base em produção nem armazene conversas reais nela.

## 1. Iniciar o servidor
Requisitos: Docker Desktop ou Docker Engine + Docker Compose, Node.js 20+.

No terminal, entre em `server` e execute:

```bash
docker compose up -d postgres
cp .env.example .env
npm install
npm run db:init
npm run dev
```

A API ficará em `http://localhost:3000`.

## 2. Iniciar no Android
Requisitos: Flutter SDK instalado e Android SDK configurado.

Entre em `mobile` e execute:

```bash
flutter pub get
flutter run
```

### Endereço da API
- Emulador Android padrão: `http://10.0.2.2:3000`
- Celular físico: altere `apiBaseUrl` em `mobile/lib/main.dart` para `http://IP_DO_SEU_COMPUTADOR:3000`, com celular e computador na mesma rede Wi-Fi.
- Para acesso pela internet, publique a API atrás de HTTPS e configure autenticação, firewall e domínio. Não exponha a porta do PostgreSQL à internet.

## 3. Criar APK de teste
Dentro de `mobile`:

```bash
flutter build apk --debug
```

O APK de depuração será gerado em `build/app/outputs/flutter-apk/app-debug.apk`.

## Observações importantes
- O SQL é executado no banco `mglass` e cria o schema `mglass`.
- O login nesta base é um login provisório da API. A arquitetura final deve integrar a identidade com Matrix Synapse.
- O servidor usa HTTP local apenas para desenvolvimento. Produção exige HTTPS.
- O segredo JWT em `.env.example` é apenas um valor demonstrativo; substitua por um segredo forte antes de qualquer teste compartilhado.
