import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

const apiBaseUrl = 'http://10.0.2.2:3000'; // Em celular físico, use o IP local do computador.

void main() => runApp(const MGlassApp());

class MGlassApp extends StatelessWidget {
  const MGlassApp({super.key});

  @override
  Widget build(BuildContext context) {
    const navy = Color(0xFF10152F);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'MGlass',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: navy,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF7867FF),
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.white.withOpacity(.08),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: BorderSide.none,
          ),
        ),
      ),
      home: const AuthGate(),
    );
  }
}

class Api {
  static Future<Map<String, dynamic>> request(
    String path, {
    String method = 'GET',
    Map<String, dynamic>? body,
    String? token,
  }) async {
    final uri = Uri.parse('$apiBaseUrl$path');
    final headers = <String, String>{'Content-Type': 'application/json'};
    if (token != null) headers['Authorization'] = 'Bearer $token';

    late http.Response response;
    if (method == 'POST') {
      response = await http.post(uri, headers: headers, body: jsonEncode(body ?? {}));
    } else {
      response = await http.get(uri, headers: headers);
    }
    final data = response.body.isEmpty ? <String, dynamic>{} :
        jsonDecode(response.body) as Map<String, dynamic>;
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw Exception(data['error'] ?? 'Falha na comunicação com o servidor');
    }
    return data;
  }
}

class AuthGate extends StatefulWidget {
  const AuthGate({super.key});
  @override
  State<AuthGate> createState() => _AuthGateState();
}

class _AuthGateState extends State<AuthGate> {
  String? token;
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getString('token');
    if (saved != null) {
      try {
        await Api.request('/api/me', token: saved);
        token = saved;
      } catch (_) {
        await prefs.remove('token');
      }
    }
    if (mounted) setState(() => loading = false);
  }

  Future<void> onLogin(String newToken) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('token', newToken);
    if (mounted) setState(() => token = newToken);
  }

  Future<void> onLogout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('token');
    if (mounted) setState(() => token = null);
  }

  @override
  Widget build(BuildContext context) {
    if (loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    if (token == null) return LoginPage(onLogin: onLogin);
    return HomePage(token: token!, onLogout: onLogout);
  }
}

class LoginPage extends StatefulWidget {
  final Future<void> Function(String) onLogin;
  const LoginPage({super.key, required this.onLogin});
  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final username = TextEditingController();
  final password = TextEditingController();
  final displayName = TextEditingController();
  bool register = false;
  bool busy = false;
  String? error;

  Future<void> submit() async {
    setState(() { busy = true; error = null; });
    try {
      final result = await Api.request(
        register ? '/api/auth/register' : '/api/auth/login',
        method: 'POST',
        body: {
          'username': username.text.trim(),
          'password': password.text,
          if (register) 'displayName': displayName.text.trim(),
        },
      );
      await widget.onLogin(result['token'] as String);
    } catch (e) {
      setState(() => error = e.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  void dispose() {
    username.dispose(); password.dispose(); displayName.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft, end: Alignment.bottomRight,
            colors: [Color(0xFF151B45), Color(0xFF24164B), Color(0xFF090D20)],
          ),
        ),
        child: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(26),
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 440),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const Icon(Icons.blur_on_rounded, size: 76, color: Color(0xFF9B91FF)),
                    const SizedBox(height: 8),
                    const Text('MGlass', textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 38, fontWeight: FontWeight.w800, letterSpacing: 1.2)),
                    const Text('Suas conversas, em um só lugar',
                      textAlign: TextAlign.center, style: TextStyle(color: Colors.white70)),
                    const SizedBox(height: 36),
                    Text(register ? 'Criar conta' : 'Bem-vindo de volta',
                      style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 18),
                    if (register) ...[
                      TextField(controller: displayName, decoration: const InputDecoration(labelText: 'Nome de exibição')),
                      const SizedBox(height: 12),
                    ],
                    TextField(controller: username, autocorrect: false,
                      decoration: const InputDecoration(labelText: 'Nome de usuário')),
                    const SizedBox(height: 12),
                    TextField(controller: password, obscureText: true,
                      decoration: const InputDecoration(labelText: 'Senha')),
                    if (error != null) ...[
                      const SizedBox(height: 12),
                      Text(error!, style: const TextStyle(color: Colors.redAccent)),
                    ],
                    const SizedBox(height: 22),
                    FilledButton(
                      onPressed: busy ? null : submit,
                      style: FilledButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 16)),
                      child: busy ? const CircularProgressIndicator() :
                        Text(register ? 'Criar minha conta' : 'Entrar'),
                    ),
                    TextButton(
                      onPressed: busy ? null : () => setState(() { register = !register; error = null; }),
                      child: Text(register ? 'Já tenho uma conta' : 'Não tenho uma conta — criar'),
                    ),
                    const SizedBox(height: 12),
                    const Text('Versão inicial de desenvolvimento. Não use senha reutilizada de outros serviços.',
                      textAlign: TextAlign.center, style: TextStyle(fontSize: 11, color: Colors.white54)),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class HomePage extends StatefulWidget {
  final String token;
  final Future<void> Function() onLogout;
  const HomePage({super.key, required this.token, required this.onLogout});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  Map<String, dynamic>? me;
  String? error;

  @override
  void initState() { super.initState(); load(); }

  Future<void> load() async {
    try {
      final data = await Api.request('/api/me', token: widget.token);
      if (mounted) setState(() => me = data['user'] as Map<String, dynamic>);
    } catch (e) {
      if (mounted) setState(() => error = e.toString());
    }
  }

  @override
  Widget build(BuildContext context) {
    final name = me?['displayName'] ?? me?['username'] ?? 'MGlass';
    return Scaffold(
      appBar: AppBar(
        title: const Text('MGlass'),
        actions: [IconButton(onPressed: widget.onLogout, icon: const Icon(Icons.logout), tooltip: 'Sair')],
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Container(
            width: double.infinity, padding: const EdgeInsets.all(22),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(24),
              gradient: const LinearGradient(colors: [Color(0xFF5554C9), Color(0xFF8A58B8)]),
              border: Border.all(color: Colors.white24),
            ),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Olá,', style: TextStyle(color: Colors.white70)),
              Text('$name', style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              const Text('Sua conta MGlass está conectada ao servidor.'),
            ]),
          ),
          const SizedBox(height: 26),
          const Text('Conversas', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          const Card(child: ListTile(
            leading: CircleAvatar(child: Icon(Icons.chat_bubble_outline)),
            title: Text('Mensagens em preparação'),
            subtitle: Text('A integração com Matrix será a próxima etapa.'),
          )),
          const Card(child: ListTile(
            leading: CircleAvatar(child: Icon(Icons.security)),
            title: Text('Segurança'),
            subtitle: Text('Login conectado à API. Criptografia E2EE ainda não ativada.'),
          )),
          if (error != null) Text(error!, style: const TextStyle(color: Colors.redAccent)),
        ]),
      ),
    );
  }
}
