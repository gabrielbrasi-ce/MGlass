-- MGlass — schema complementar PostgreSQL
-- Versão inicial: 1.0
-- Compatível com PostgreSQL 15+
-- IMPORTANTE:
--   * Este schema NÃO substitui nem modifica o banco interno do Matrix Synapse.
--   * Mensagens, salas, eventos e chaves E2EE permanecem sob responsabilidade do Matrix.
--   * Execute primeiro em ambiente de desenvolvimento e revise antes de produção.

BEGIN;

CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE EXTENSION IF NOT EXISTS citext;

CREATE SCHEMA IF NOT EXISTS mglass;
SET search_path TO mglass, public;

-- 1. Usuários
CREATE TABLE IF NOT EXISTS users (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    matrix_user_id      VARCHAR(255) NOT NULL UNIQUE,
    username            CITEXT NOT NULL UNIQUE,
    account_status      VARCHAR(20) NOT NULL DEFAULT 'active'
                        CHECK (account_status IN ('pending', 'active', 'suspended', 'deleted')),
    created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 2. Mídias (crie antes de profiles e groups para permitir FKs)
CREATE TABLE IF NOT EXISTS media_objects (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    owner_id            UUID REFERENCES users(id) ON DELETE SET NULL,
    storage_key         TEXT NOT NULL UNIQUE,
    media_type          VARCHAR(20) NOT NULL
                        CHECK (media_type IN ('image', 'video', 'audio', 'document', 'other')),
    mime_type           VARCHAR(255) NOT NULL,
    file_size           BIGINT NOT NULL CHECK (file_size >= 0),
    encrypted           BOOLEAN NOT NULL DEFAULT TRUE,
    checksum            VARCHAR(255),
    created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    deleted_at          TIMESTAMPTZ,
    CHECK (deleted_at IS NULL OR deleted_at >= created_at)
);

-- 3. Perfis
CREATE TABLE IF NOT EXISTS profiles (
    user_id                 UUID PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
    display_name            VARCHAR(80) NOT NULL,
    biography               VARCHAR(500),
    avatar_media_id         UUID REFERENCES media_objects(id) ON DELETE SET NULL,
    theme                   VARCHAR(30) NOT NULL DEFAULT 'liquid_glass_blue_purple',
    last_seen_visibility    VARCHAR(20) NOT NULL DEFAULT 'contacts'
                            CHECK (last_seen_visibility IN ('everyone', 'contacts', 'nobody')),
    profile_visibility      VARCHAR(20) NOT NULL DEFAULT 'everyone'
                            CHECK (profile_visibility IN ('everyone', 'contacts', 'nobody')),
    updated_at              TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 4. Contatos (relação direcionada; A pode adicionar B sem B adicionar A)
CREATE TABLE IF NOT EXISTS contacts (
    user_id             UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    contact_user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    nickname            VARCHAR(80),
    created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (user_id, contact_user_id),
    CHECK (user_id <> contact_user_id)
);

-- 5. Bloqueios (direcionados)
CREATE TABLE IF NOT EXISTS blocks (
    blocker_id          UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    blocked_id          UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    reason              VARCHAR(500),
    created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (blocker_id, blocked_id),
    CHECK (blocker_id <> blocked_id)
);

-- 6. Grupos
CREATE TABLE IF NOT EXISTS groups (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    matrix_room_id      VARCHAR(255) NOT NULL UNIQUE,
    name                VARCHAR(100) NOT NULL,
    description         VARCHAR(1000),
    avatar_media_id     UUID REFERENCES media_objects(id) ON DELETE SET NULL,
    created_by          UUID REFERENCES users(id) ON DELETE SET NULL,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 7. Participantes de grupos
CREATE TABLE IF NOT EXISTS group_members (
    group_id            UUID NOT NULL REFERENCES groups(id) ON DELETE CASCADE,
    user_id             UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    local_role          VARCHAR(20) NOT NULL DEFAULT 'member'
                        CHECK (local_role IN ('owner', 'admin', 'moderator', 'member')),
    joined_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
    left_at             TIMESTAMPTZ,
    PRIMARY KEY (group_id, user_id),
    CHECK (left_at IS NULL OR left_at >= joined_at)
);

-- 8. Configurações de grupo
CREATE TABLE IF NOT EXISTS group_settings (
    group_id                UUID PRIMARY KEY REFERENCES groups(id) ON DELETE CASCADE,
    approval_required       BOOLEAN NOT NULL DEFAULT FALSE,
    members_can_invite      BOOLEAN NOT NULL DEFAULT TRUE,
    history_visibility      VARCHAR(20) NOT NULL DEFAULT 'joined'
                            CHECK (history_visibility IN ('joined', 'invited', 'world_readable')),
    updated_at              TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 9. Status / stories
CREATE TABLE IF NOT EXISTS stories (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id             UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    media_id            UUID NOT NULL REFERENCES media_objects(id) ON DELETE RESTRICT,
    caption             VARCHAR(700),
    created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    expires_at          TIMESTAMPTZ NOT NULL,
    CHECK (expires_at > created_at)
);

-- 10. Visualizações de status
CREATE TABLE IF NOT EXISTS story_views (
    story_id            UUID NOT NULL REFERENCES stories(id) ON DELETE CASCADE,
    viewer_id           UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    viewed_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (story_id, viewer_id)
);

-- 11. Fila auxiliar de expiração de mensagens Matrix
CREATE TABLE IF NOT EXISTS message_expirations (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    matrix_room_id      VARCHAR(255) NOT NULL,
    matrix_event_id     VARCHAR(255) NOT NULL,
    sender_id           UUID REFERENCES users(id) ON DELETE SET NULL,
    expiration_seconds  INTEGER NOT NULL
                        CHECK (expiration_seconds IN (30, 3600, 86400, 604800)),
    expires_at          TIMESTAMPTZ NOT NULL,
    processed_at        TIMESTAMPTZ,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (matrix_room_id, matrix_event_id)
);

-- 12. Configurações de privacidade
CREATE TABLE IF NOT EXISTS privacy_settings (
    user_id                     UUID PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
    allow_messages_from          VARCHAR(20) NOT NULL DEFAULT 'everyone'
                                CHECK (allow_messages_from IN ('everyone', 'contacts', 'nobody')),
    allow_calls_from             VARCHAR(20) NOT NULL DEFAULT 'everyone'
                                CHECK (allow_calls_from IN ('everyone', 'contacts', 'nobody')),
    allow_group_invites_from     VARCHAR(20) NOT NULL DEFAULT 'everyone'
                                CHECK (allow_group_invites_from IN ('everyone', 'contacts', 'nobody')),
    show_online_status           BOOLEAN NOT NULL DEFAULT TRUE,
    show_read_receipts           BOOLEAN NOT NULL DEFAULT TRUE,
    updated_at                   TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 13. Dispositivos para push
CREATE TABLE IF NOT EXISTS push_devices (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id             UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    matrix_device_id    VARCHAR(255),
    platform            VARCHAR(20) NOT NULL CHECK (platform IN ('android', 'ios', 'web')),
    push_token          TEXT NOT NULL,
    active              BOOLEAN NOT NULL DEFAULT TRUE,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    last_seen_at        TIMESTAMPTZ,
    UNIQUE (platform, push_token)
);

-- 14. Denúncias
CREATE TABLE IF NOT EXISTS reports (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    reporter_id         UUID REFERENCES users(id) ON DELETE SET NULL,
    reported_user_id    UUID REFERENCES users(id) ON DELETE SET NULL,
    matrix_room_id      VARCHAR(255),
    matrix_event_id     VARCHAR(255),
    category            VARCHAR(40) NOT NULL
                        CHECK (category IN ('spam', 'harassment', 'impersonation', 'illegal_content', 'other')),
    description         TEXT,
    status              VARCHAR(20) NOT NULL DEFAULT 'open'
                        CHECK (status IN ('open', 'under_review', 'resolved', 'dismissed')),
    created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    resolved_at         TIMESTAMPTZ,
    CHECK (reporter_id IS NULL OR reported_user_id IS NULL OR reporter_id <> reported_user_id)
);

-- 15. Chamadas (metadados; mídia/áudio não é armazenada aqui)
CREATE TABLE IF NOT EXISTS calls (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    matrix_room_id      VARCHAR(255),
    livekit_room_name   VARCHAR(255) NOT NULL UNIQUE,
    initiated_by        UUID REFERENCES users(id) ON DELETE SET NULL,
    call_type           VARCHAR(20) NOT NULL CHECK (call_type IN ('voice', 'video')),
    status              VARCHAR(20) NOT NULL DEFAULT 'created'
                        CHECK (status IN ('created', 'ringing', 'active', 'ended', 'failed', 'cancelled')),
    started_at          TIMESTAMPTZ,
    ended_at            TIMESTAMPTZ,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    CHECK (ended_at IS NULL OR started_at IS NULL OR ended_at >= started_at)
);

-- 16. Recuperação de conta: armazenar somente hash de token/código
CREATE TABLE IF NOT EXISTS account_recovery (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id             UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    recovery_method     VARCHAR(30) NOT NULL
                        CHECK (recovery_method IN ('recovery_key', 'recovery_code', 'trusted_device')),
    token_hash          TEXT NOT NULL,
    expires_at          TIMESTAMPTZ NOT NULL,
    used_at             TIMESTAMPTZ,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 17. Logs de auditoria
CREATE TABLE IF NOT EXISTS audit_logs (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    actor_user_id       UUID REFERENCES users(id) ON DELETE SET NULL,
    action              VARCHAR(100) NOT NULL,
    target_type         VARCHAR(80),
    target_id           VARCHAR(255),
    metadata            JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 18. Consentimentos
CREATE TABLE IF NOT EXISTS user_consents (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id             UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    consent_type        VARCHAR(80) NOT NULL,
    policy_version      VARCHAR(40) NOT NULL,
    accepted_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
    revoked_at          TIMESTAMPTZ,
    CHECK (revoked_at IS NULL OR revoked_at >= accepted_at)
);

-- 19. Tarefas de exclusão de mídia
CREATE TABLE IF NOT EXISTS media_deletion_jobs (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    media_id            UUID NOT NULL REFERENCES media_objects(id) ON DELETE CASCADE,
    status              VARCHAR(20) NOT NULL DEFAULT 'pending'
                        CHECK (status IN ('pending', 'processing', 'completed', 'failed')),
    attempts            INTEGER NOT NULL DEFAULT 0 CHECK (attempts >= 0),
    scheduled_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
    completed_at        TIMESTAMPTZ,
    last_error          TEXT,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Índices de consulta e filas de processamento
CREATE INDEX IF NOT EXISTS idx_contacts_contact_user ON contacts(contact_user_id);
CREATE INDEX IF NOT EXISTS idx_blocks_blocked ON blocks(blocked_id);
CREATE INDEX IF NOT EXISTS idx_groups_created_by ON groups(created_by);
CREATE INDEX IF NOT EXISTS idx_group_members_user ON group_members(user_id);
CREATE INDEX IF NOT EXISTS idx_group_members_active ON group_members(group_id, user_id) WHERE left_at IS NULL;
CREATE INDEX IF NOT EXISTS idx_media_owner_created ON media_objects(owner_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_media_deleted ON media_objects(deleted_at) WHERE deleted_at IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_stories_user_created ON stories(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_stories_expiration ON stories(expires_at);
CREATE INDEX IF NOT EXISTS idx_story_views_viewer ON story_views(viewer_id, viewed_at DESC);
CREATE INDEX IF NOT EXISTS idx_message_expirations_due ON message_expirations(expires_at)
    WHERE processed_at IS NULL;
CREATE INDEX IF NOT EXISTS idx_push_devices_user_active ON push_devices(user_id) WHERE active = TRUE;
CREATE INDEX IF NOT EXISTS idx_reports_status_created ON reports(status, created_at);
CREATE INDEX IF NOT EXISTS idx_reports_reported_user ON reports(reported_user_id);
CREATE INDEX IF NOT EXISTS idx_calls_initiated_created ON calls(initiated_by, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_account_recovery_user_expiry ON account_recovery(user_id, expires_at);
CREATE INDEX IF NOT EXISTS idx_audit_logs_actor_created ON audit_logs(actor_user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_audit_logs_target ON audit_logs(target_type, target_id);
CREATE INDEX IF NOT EXISTS idx_user_consents_user_type ON user_consents(user_id, consent_type);
CREATE INDEX IF NOT EXISTS idx_media_deletion_jobs_due ON media_deletion_jobs(scheduled_at)
    WHERE status IN ('pending', 'failed');

-- Índices para FKs usadas em consultas de avatar
CREATE INDEX IF NOT EXISTS idx_profiles_avatar_media ON profiles(avatar_media_id);
CREATE INDEX IF NOT EXISTS idx_groups_avatar_media ON groups(avatar_media_id);

COMMIT;

-- NOTAS OPERACIONAIS:
-- 1) Atualize updated_at na aplicação ou por triggers padronizadas.
-- 2) A aplicação deve validar autorização e sincronizar memberships com Matrix.
-- 3) Um worker deve processar message_expirations: solicitar redaction via API Matrix,
--    confirmar o resultado e marcar processed_at; não apagar eventos diretamente no DB Matrix.
-- 4) Um worker deve processar stories expirados e media_deletion_jobs, removendo objetos S3
--    somente após verificar referências e política de retenção.
-- 5) Criptografe arquivos no cliente antes do upload. Nunca armazene chaves privadas E2EE
--    ou tokens de recuperação em texto puro.
-- 6) Restrinja acesso a push_token, token_hash e metadata; use TLS, backups criptografados,
--    roles com privilégio mínimo e segredos fora do banco.
-- 7) A tabela calls registra chamadas, mas participantes exigem uma tabela adicional
--    call_participants (não incluída no escopo de 19 tabelas).
-- 8) Este script não configura autenticação Matrix, LiveKit, S3, TURN, push nem workers.


-- Credenciais provisórias da API de desenvolvimento.
-- Na arquitetura final, a autenticação deverá ser integrada ao Matrix Synapse.
CREATE TABLE IF NOT EXISTS mglass.api_credentials (
    user_id UUID PRIMARY KEY REFERENCES mglass.users(id) ON DELETE CASCADE,
    password_hash TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
