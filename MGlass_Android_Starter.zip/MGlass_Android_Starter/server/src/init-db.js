import fs from 'node:fs';
import { pool } from './db.js';
const sql = fs.readFileSync(new URL('../db/schema.sql', import.meta.url), 'utf8');
try {
  await pool.query(sql);
  console.log('Schema MGlass instalado.');
} catch (err) {
  console.error('Falha ao instalar schema:', err.message);
  process.exitCode = 1;
} finally {
  await pool.end();
}
