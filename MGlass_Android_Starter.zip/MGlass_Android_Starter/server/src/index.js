import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import dotenv from 'dotenv';
import { pool } from './db.js';
dotenv.config();

if (!process.env.JWT_SECRET || process.env.JWT_SECRET.includes('replace_with')) {
  console.error('Configure JWT_SECRET em .env antes de iniciar a API.');
  process.exit(1);
}
const app = express();
app.use(helmet());
app.use(cors());
app.use(express.json({ limit: '1mb' }));

app.get('/health', async (_req, res) => {
  try { await pool.query('SELECT 1'); res.json({ ok: true, service: 'mglass-api' }); }
  catch { res.status(503).json({ ok: false }); }
});

function auth(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) return res.status(401).json({ error: 'Faça login novamente.' });
  try { req.user = jwt.verify(token, process.env.JWT_SECRET); next(); }
  catch { return res.status(401).json({ error: 'Sessão inválida ou expirada.' }); }
}

app.post('/api/auth/register', async (req, res) => {
  const username = String(req.body.username || '').trim().toLowerCase();
  const password = String(req.body.password || '');
  const displayName = String(req.body.displayName || username).trim();
  if (!/^[a-z0-9_]{3,24}$/.test(username))
    return res.status(400).json({ error: 'Use 3–24 caracteres: letras, números ou _.' });
  if (password.length < 10)
    return res.status(400).json({ error: 'A senha precisa ter pelo menos 10 caracteres.' });
  if (!displayName || displayName.length > 80)
    return res.status(400).json({ error: 'Nome de exibição inválido.' });
  try {
    const hash = await bcrypt.hash(password, 12);
    const client = await pool.connect();
    let user;
    try {
      await client.query('BEGIN');
      const created = await client.query(
        `INSERT INTO mglass.users(matrix_user_id, username)
         VALUES ($1, $2) RETURNING id, username`,
        [`@${username}:mglass.local`, username]
      );
      user = created.rows[0];
      await client.query(
        `INSERT INTO mglass.profiles(user_id, display_name) VALUES ($1, $2)`,
        [user.id, displayName]
      );
      await client.query(
        `INSERT INTO mglass.privacy_settings(user_id) VALUES ($1)`,
        [user.id]
      );
      // Nesta base inicial, o hash fica em tabela de credenciais da API.
      await client.query(
        `INSERT INTO mglass.api_credentials(user_id, password_hash) VALUES ($1, $2)`,
        [user.id, hash]
      );
      await client.query('COMMIT');
    } catch (e) { await client.query('ROLLBACK'); throw e; }
    finally { client.release(); }
    const token = jwt.sign({ sub: user.id }, process.env.JWT_SECRET, { expiresIn: '7d' });
    res.status(201).json({ token, user: { id: user.id, username: user.username, displayName } });
  } catch (e) {
    if (e.code === '23505') return res.status(409).json({ error: 'Esse nome de usuário já está em uso.' });
    console.error(e);
    res.status(500).json({ error: 'Não foi possível criar a conta.' });
  }
});

app.post('/api/auth/login', async (req, res) => {
  const username = String(req.body.username || '').trim().toLowerCase();
  const password = String(req.body.password || '');
  try {
    const result = await pool.query(
      `SELECT u.id, u.username, p.display_name, c.password_hash
       FROM mglass.users u
       JOIN mglass.api_credentials c ON c.user_id = u.id
       LEFT JOIN mglass.profiles p ON p.user_id = u.id
       WHERE u.username = $1 AND u.account_status = 'active'`,
      [username]
    );
    const row = result.rows[0];
    if (!row || !(await bcrypt.compare(password, row.password_hash)))
      return res.status(401).json({ error: 'Usuário ou senha incorretos.' });
    const token = jwt.sign({ sub: row.id }, process.env.JWT_SECRET, { expiresIn: '7d' });
    res.json({ token, user: { id: row.id, username: row.username, displayName: row.display_name } });
  } catch (e) { console.error(e); res.status(500).json({ error: 'Falha ao entrar.' }); }
});

app.get('/api/me', auth, async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT u.id, u.username, p.display_name AS "displayName", p.biography
       FROM mglass.users u LEFT JOIN mglass.profiles p ON p.user_id = u.id
       WHERE u.id = $1 AND u.account_status = 'active'`,
      [req.user.sub]
    );
    if (!result.rows[0]) return res.status(404).json({ error: 'Conta não encontrada.' });
    res.json({ user: result.rows[0] });
  } catch { res.status(500).json({ error: 'Falha ao consultar perfil.' }); }
});

app.listen(Number(process.env.PORT || 3000), '0.0.0.0', () =>
  console.log(`MGlass API ouvindo na porta ${process.env.PORT || 3000}`)
);
